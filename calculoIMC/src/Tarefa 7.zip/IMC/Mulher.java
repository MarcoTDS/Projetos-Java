package IMC;

public class Mulher extends Atletas {

}
