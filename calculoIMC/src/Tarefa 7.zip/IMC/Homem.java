package IMC;

public class Homem extends Atletas {

}
